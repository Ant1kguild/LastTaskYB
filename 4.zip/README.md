# FinalTaskYellowBelt
ссылкана задание https://www.coursera.org/learn/c-plus-plus-yellow/programming/n1Nbg/kursovoi-proiekt/submission
после последних моих оптимизаций начало ругатся снова на 5 кейс, на форуме пишут ошибка в  EventComparisonNode
все проекты которые  я до этого сбрасивыл лежат в архивах 1-7, 7 последний
