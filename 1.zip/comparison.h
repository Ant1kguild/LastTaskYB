//
// Created by ant1k on 18.3.18.
//

#pragma once


enum class Comparison {
    Less,
    LessOrEqual,
    Greater,
    GreaterOrEqual,
    Equal,
    NotEqual
};

