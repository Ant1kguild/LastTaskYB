//
// Created by ant1k on 16.3.18.
//

#pragma once

#include "date.h"
#include "node.h"
#include <map>
#include <algorithm>
#include <functional>
#include <set>


struct DateEvent {
    std::map<Date, std::vector<string>> dates;
    std::map<std::string, std::set<Date>> events;

    std::map<Date, std::vector<string>>::iterator
    find(Date const &date) { return dates.find(date); }

    std::map<std::string, std::set<Date>>::iterator
    find(string const &event) { return events.find(event); }

    void add(Date const &date, string const &event) {
        auto dateIterator = find(date);
        auto eventIterator = find(event);

        const bool hasDate = dateIterator != dates.end();
        const bool hasEvent = eventIterator != events.end();

        if (hasDate && hasEvent) {
            return;
        }
        if (hasDate && !hasEvent) {
            dateIterator->second.push_back(event);
            events.insert(make_pair(event, set<Date>{date}));
            return;
        }
        if (!hasDate && hasEvent) {
            dates.insert(make_pair(date, vector<string>{event}));
            eventIterator->second.insert(date);
        }

        if (!hasDate && !hasEvent) {
            dates.insert(make_pair(date, vector<string>{event}));
            events.insert(make_pair(event, set<Date>{date}));
        }
    }
};

enum class Cursor {
    NEXT_DATE,
    NEXT_EVENT,
    THIS
};


class Database {
public:
    void Add(const Date &date, const std::string &event);

    void Print(std::ostream &cout);

    using Predicate =  std::function<PredicateIt(const Date &, const std::string &)>;

    std::string RemoveIf(const Predicate &predicate);

    std::vector<pair<Date, std::string>> FindIf(const Predicate &predicate);

    friend void TestAddDateEvent();

    std::string Last(const Date &date);

private:
    DateEvent database;

    Cursor findByPredicate(const Predicate &function,
                           map<Date, std::vector<std::string>>::iterator dateIterator,
                           std::vector<string>::iterator eventIterator);
};


std::ostream &operator<<(std::ostream &stream, const std::pair<Date, std::string> &map);

void TestAddDateEvent();